# Loja & Estoque — Projeto Final

Aplicação de terminal em Python para gerenciar produtos, clientes e pedidos
de uma loja fictícia, desenvolvida como projeto final da disciplina.

## Objetivo

Aplicar de forma integrada os conceitos estudados na disciplina — desde a
base da linguagem (variáveis, laços, condicionais, listas) até Programação
Orientada a Objetos (classes, herança, encapsulamento, abstração e
polimorfismo) — construindo um sistema funcional de loja/estoque via
terminal.

## Integrantes

- Nome 1 — RA/Matrícula
- Nome 2 — RA/Matrícula
- Nome 3 — RA/Matrícula
- Nome 4 — RA/Matrícula

*(preencher com os nomes reais do grupo)*

## Funcionalidades

- Cadastro de produtos **físicos** (com peso e cálculo de frete) e
  **digitais** (com tamanho de arquivo, sem frete).
- Listagem, busca e remoção de produtos do estoque.
- Cadastro e listagem de clientes, cada um com saldo próprio.
- Criação de pedidos (carrinho): adicionar/remover itens.
- Cálculo automático de subtotal, frete e total do pedido.
- Finalização de pedido com débito do saldo do cliente.
- Histórico de pedidos finalizados.

## Diagrama simples das classes

```
                 Produto (abstrata)
               /_nome, _preco, _quantidade
              / calcular_frete() [abstrato]
             /
  ProdutoFisico          ProdutoDigital
  + peso_kg               + tamanho_mb
  calcular_frete()        calcular_frete()
  (frete por peso)        (sempre 0.0)


  Cliente                     Estoque
  - _nome, _cpf, _saldo       - _produtos: list[Produto]
  + depositar()               + adicionar_produto()
  + debitar()                 + remover_produto()
                               + buscar_por_nome()

  Pedido
  - numero, cliente, itens: list[Produto], finalizado
  + adicionar_item() / remover_item()
  + calcular_subtotal() / calcular_frete_total() / calcular_total()
  + finalizar()
```

**Relação de herança:** `ProdutoFisico` e `ProdutoDigital` herdam de `Produto`.
**Abstração:** `Produto` é uma classe abstrata (`ABC`) com o método
`calcular_frete()` obrigatório para as subclasses.
**Encapsulamento:** atributos como `_nome`, `_preco`, `_saldo` são acessados
por meio de `@property`, protegendo o estado interno dos objetos.
**Polimorfismo:** o mesmo método `calcular_frete()` (e `__str__()`) se
comporta de forma diferente dependendo da classe do produto.

## Estrutura de pastas

```
loja-estoque/
├── main.py            # ponto de entrada, menus, input()/print()
├── estoque.py          # classe Estoque
├── servicos.py         # funções auxiliares (validação, formatação)
├── modelos/
│   ├── __init__.py
│   ├── produto.py       # Produto (abstrata), ProdutoFisico, ProdutoDigital
│   ├── cliente.py       # Cliente
│   └── pedido.py        # Pedido (carrinho de compras)
├── README.md
└── .gitignore
```

## Como executar

Pré-requisito: Python 3.9+ instalado.

```bash
git clone <link-do-repositorio>
cd loja-estoque
python3 main.py
```

Depois é só seguir o menu numerado que aparece no terminal.

## Conceitos da disciplina aplicados

Comentários, variáveis, `print()`, `input()`, f-strings, `type()`,
conversão de tipos, operadores aritméticos/comparação/lógicos, `abs()`,
listas com `append()`/`pop()`, `len()`, `is`/`is not`, `in`/`not in`,
`if`/`elif`/`else`, `range()`, laços `for` e `while`, funções (com e sem
parâmetros), classes/objetos/atributos/métodos, abstração, encapsulamento,
herança e polimorfismo.
