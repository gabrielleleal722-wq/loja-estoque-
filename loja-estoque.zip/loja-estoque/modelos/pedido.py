# modelos/pedido.py
# Classe que representa um pedido (carrinho de compras) de um cliente.


class Pedido:
    """Representa um pedido feito por um cliente, com vários produtos."""

    contador_pedidos = 0  # atributo de CLASSE (compartilhado por todos os objetos)

    def __init__(self, cliente):
        Pedido.contador_pedidos += 1
        self.numero = Pedido.contador_pedidos
        self.cliente = cliente
        self.itens = []          # lista de produtos -> append()/pop()
        self.finalizado = False

    def adicionar_item(self, produto):
        """Adiciona um produto ao pedido, se houver estoque disponível."""
        if produto.esta_disponivel():
            self.itens.append(produto)   # append()
            produto.quantidade = produto.quantidade - 1
            return True
        return False

    def remover_item(self, indice):
        """Remove um item do pedido pelo índice na lista."""
        if 0 <= indice < len(self.itens):
            item_removido = self.itens.pop(indice)  # pop()
            item_removido.quantidade = item_removido.quantidade + 1
            return item_removido
        return None

    def calcular_subtotal(self):
        total = 0.0
        for item in self.itens:            # for
            total += item.preco
        return total

    def calcular_frete_total(self):
        total_frete = 0.0
        for item in self.itens:            # POLIMORFISMO em ação:
            total_frete += item.calcular_frete()  # cada item calcula do seu jeito
        return total_frete

    def calcular_total(self):
        return self.calcular_subtotal() + self.calcular_frete_total()

    def esta_vazio(self):
        return len(self.itens) == 0

    def finalizar(self):
        """Tenta debitar o total do saldo do cliente e fechar o pedido."""
        if self.esta_vazio():
            return False

        total = self.calcular_total()
        conseguiu_pagar = self.cliente.debitar(total)

        if conseguiu_pagar:
            self.finalizado = True

        return conseguiu_pagar

    def __str__(self):
        status = "Finalizado" if self.finalizado else "Em aberto"
        return f"Pedido #{self.numero} - {self.cliente.nome} - {len(self.itens)} item(ns) - {status}"
