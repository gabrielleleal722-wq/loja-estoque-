# modelos/produto.py
# Classes que representam os produtos vendidos pela loja.

from abc import ABC, abstractmethod


class Produto(ABC):
    """
    Classe ABSTRATA que representa um produto genérico da loja.

    Ela não pode ser instanciada diretamente (abstração): serve apenas
    como um "molde" para as classes filhas ProdutoFisico e ProdutoDigital.
    """

    def __init__(self, nome, preco, quantidade):
        # Atributos "protegidos" (prefixo _) -> ENCAPSULAMENTO.
        # O acesso de fora da classe deve ser feito pelas properties abaixo,
        # e não diretamente pelo atributo.
        self._nome = nome
        self._preco = float(preco)          # conversão de tipo
        self._quantidade = int(quantidade)   # conversão de tipo

    # ---------- Propriedades (encapsulamento com getters/setters) ----------
    @property
    def nome(self):
        return self._nome

    @property
    def preco(self):
        return self._preco

    @property
    def quantidade(self):
        return self._quantidade

    @quantidade.setter
    def quantidade(self, nova_quantidade):
        # Validação simples usando operador de comparação
        if nova_quantidade < 0:
            raise ValueError("Quantidade não pode ser negativa.")
        self._quantidade = nova_quantidade

    # ---------- Método abstrato: cada subclasse implementa do seu jeito ----------
    @abstractmethod
    def calcular_frete(self):
        """Cada tipo de produto calcula o frete de um jeito (POLIMORFISMO)."""
        pass

    # ---------- Métodos "normais", já prontos para todas as subclasses ----------
    def valor_total_em_estoque(self):
        # operador aritmético
        return self._preco * self._quantidade

    def esta_disponivel(self):
        # operador de comparação + retorno booleano
        return self._quantidade > 0

    def __str__(self):
        # Representação padrão em texto (usada pelo print())
        return f"{self._nome} - R$ {self._preco:.2f} ({self._quantidade} un.)"


class ProdutoFisico(Produto):
    """Produto que precisa ser enviado fisicamente (tem peso e gera frete)."""

    def __init__(self, nome, preco, quantidade, peso_kg):
        super().__init__(nome, preco, quantidade)  # HERANÇA
        self.peso_kg = float(peso_kg)

    def calcular_frete(self):
        # Regra própria do produto físico: R$ 5,00 por kg
        return round(self.peso_kg * 5.0, 2)

    def __str__(self):
        # POLIMORFISMO: sobrescreve o __str__ da classe mãe, reaproveitando-o
        return f"[Físico]  {super().__str__()} | peso: {self.peso_kg}kg"


class ProdutoDigital(Produto):
    """Produto de download (e-book, jogo, curso) - não gera frete."""

    def __init__(self, nome, preco, quantidade, tamanho_mb):
        super().__init__(nome, preco, quantidade)  # HERANÇA
        self.tamanho_mb = float(tamanho_mb)

    def calcular_frete(self):
        # Produto digital nunca tem frete
        return 0.0

    def __str__(self):
        # POLIMORFISMO: mesma assinatura de método, comportamento diferente
        return f"[Digital] {super().__str__()} | arquivo: {self.tamanho_mb}MB"
