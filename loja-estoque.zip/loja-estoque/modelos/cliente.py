# modelos/cliente.py
# Classe que representa um cliente da loja.


class Cliente:
    """Representa um cliente cadastrado na loja."""

    def __init__(self, nome, cpf, saldo=0.0):
        self._nome = nome
        self._cpf = cpf
        self._saldo = float(saldo)  # atributo encapsulado

    @property
    def nome(self):
        return self._nome

    @property
    def cpf(self):
        return self._cpf

    @property
    def saldo(self):
        return self._saldo

    def depositar(self, valor):
        """Adiciona saldo à conta do cliente."""
        if valor > 0:
            self._saldo += valor
            return True
        return False

    def debitar(self, valor):
        """
        Tenta debitar um valor do saldo.
        Retorna True se conseguiu, False se o saldo era insuficiente.
        """
        if valor <= self._saldo:
            self._saldo -= valor
            return True
        return False

    def __str__(self):
        return f"{self._nome} (CPF: {self._cpf}) - saldo: R$ {self._saldo:.2f}"
