# main.py
# Ponto de entrada da aplicação "Loja & Estoque".
# Responsável pelos menus, leitura de dados (input) e exibição (print).

from modelos.produto import ProdutoFisico, ProdutoDigital
from modelos.cliente import Cliente
from modelos.pedido import Pedido
from estoque import Estoque
import servicos


# ---------------------------------------------------------------------------
# Estado global simples da aplicação (poderia virar uma classe "Loja" também)
# ---------------------------------------------------------------------------
estoque = Estoque()
clientes = []          # lista de objetos Cliente
pedidos_finalizados = []  # histórico de pedidos já pagos
pedido_atual = None    # None até que um pedido seja criado


def exibir_menu_principal():
    print("\n" + "=" * 40)
    print("        LOJA & ESTOQUE - MENU")
    print("=" * 40)
    print("1  - Cadastrar produto físico")
    print("2  - Cadastrar produto digital")
    print("3  - Listar produtos do estoque")
    print("4  - Remover produto do estoque")
    print("5  - Buscar produto por nome")
    print("6  - Cadastrar cliente")
    print("7  - Listar clientes")
    print("8  - Iniciar novo pedido")
    print("9  - Adicionar item ao pedido atual")
    print("10 - Remover item do pedido atual")
    print("11 - Ver resumo do pedido atual")
    print("12 - Finalizar pedido atual")
    print("13 - Ver histórico de pedidos finalizados")
    print("0  - Sair")


# ---------------------------------------------------------------------------
# Funções de cada funcionalidade (funções COM parâmetros e SEM parâmetros)
# ---------------------------------------------------------------------------

def cadastrar_produto_fisico():
    print("\n-- Cadastro de produto físico --")
    nome = servicos.ler_texto("Nome do produto: ")

    # 'in' / 'not in' evitando nomes duplicados
    if estoque.produto_existe(nome):
        print("Já existe um produto com esse nome.")
        return

    preco = servicos.ler_float("Preço (R$): ")
    quantidade = servicos.ler_int("Quantidade em estoque: ")
    peso = servicos.ler_float("Peso (kg): ")

    produto = ProdutoFisico(nome, preco, quantidade, peso)
    estoque.adicionar_produto(produto)
    print(f"Produto cadastrado com sucesso: {produto}")


def cadastrar_produto_digital():
    print("\n-- Cadastro de produto digital --")
    nome = servicos.ler_texto("Nome do produto: ")

    if estoque.produto_existe(nome):
        print("Já existe um produto com esse nome.")
        return

    preco = servicos.ler_float("Preço (R$): ")
    quantidade = servicos.ler_int("Quantidade disponível: ")
    tamanho = servicos.ler_float("Tamanho do arquivo (MB): ")

    produto = ProdutoDigital(nome, preco, quantidade, tamanho)
    estoque.adicionar_produto(produto)
    print(f"Produto cadastrado com sucesso: {produto}")


def listar_produtos():
    print("\n-- Produtos em estoque --")
    produtos = estoque.listar()

    if len(produtos) == 0:
        print("Nenhum produto cadastrado ainda.")
        return

    servicos.listar_com_numeros(produtos)
    print(f"\nValor total em estoque: {servicos.formatar_moeda(estoque.valor_total_estoque())}")


def remover_produto():
    print("\n-- Remover produto do estoque --")
    listar_produtos()

    if len(estoque) == 0:   # __len__ sendo usado via len()
        return

    indice = servicos.ler_int("Digite o número do produto a remover: ") - 1
    produto_removido = estoque.remover_produto(indice)

    # exemplo de uso de 'is' / 'is not'
    if produto_removido is not None:
        print(f"Produto removido: {produto_removido}")
    else:
        print("Índice inválido.")


def buscar_produto():
    print("\n-- Buscar produto --")
    nome = servicos.ler_texto("Nome (ou parte do nome) do produto: ")
    produto = estoque.buscar_por_nome(nome)

    if produto is None:
        print("Produto não encontrado.")
    else:
        print(f"Encontrado: {produto}")
        # type() mostrando a classe real do objeto (demonstra polimorfismo)
        print(f"Tipo do produto: {type(produto).__name__}")


def cadastrar_cliente():
    print("\n-- Cadastro de cliente --")
    nome = servicos.ler_texto("Nome do cliente: ")
    cpf = servicos.ler_texto("CPF: ")
    saldo_inicial = servicos.ler_float("Saldo inicial (R$): ")

    cliente = Cliente(nome, cpf, saldo_inicial)
    clientes.append(cliente)
    print(f"Cliente cadastrado: {cliente}")


def listar_clientes():
    print("\n-- Clientes cadastrados --")
    servicos.listar_com_numeros(clientes)


def selecionar_cliente():
    """Função auxiliar que devolve o cliente escolhido ou None."""
    if len(clientes) == 0:
        print("Nenhum cliente cadastrado. Cadastre um cliente primeiro.")
        return None

    listar_clientes()
    indice = servicos.ler_int("Escolha o número do cliente: ") - 1

    if 0 <= indice < len(clientes):
        return clientes[indice]
    print("Índice inválido.")
    return None


def iniciar_pedido():
    global pedido_atual
    print("\n-- Novo pedido --")

    cliente = selecionar_cliente()
    if cliente is None:
        return

    pedido_atual = Pedido(cliente)
    print(f"Pedido #{pedido_atual.numero} iniciado para {cliente.nome}.")


def adicionar_item_pedido():
    if pedido_atual is None:
        print("Nenhum pedido em aberto. Inicie um pedido primeiro (opção 8).")
        return

    print("\n-- Adicionar item ao pedido --")
    listar_produtos()

    if len(estoque) == 0:
        return

    indice = servicos.ler_int("Número do produto a adicionar: ") - 1

    # condicional if/elif/else clássico
    if indice < 0 or indice >= len(estoque):
        print("Índice inválido.")
    elif not estoque.listar()[indice].esta_disponivel():
        print("Produto sem estoque disponível.")
    else:
        produto = estoque.listar()[indice]
        adicionado = pedido_atual.adicionar_item(produto)
        if adicionado:
            print(f"'{produto.nome}' adicionado ao pedido #{pedido_atual.numero}.")
        else:
            print("Não foi possível adicionar o item.")


def remover_item_pedido():
    if pedido_atual is None:
        print("Nenhum pedido em aberto.")
        return

    print("\n-- Itens do pedido atual --")
    servicos.listar_com_numeros(pedido_atual.itens)

    if pedido_atual.esta_vazio():
        return

    indice = servicos.ler_int("Número do item a remover: ") - 1
    item = pedido_atual.remover_item(indice)

    if item is not None:
        print(f"Item removido do pedido: {item.nome}")
    else:
        print("Índice inválido.")


def ver_resumo_pedido():
    if pedido_atual is None:
        print("Nenhum pedido em aberto.")
        return

    print(f"\n-- Resumo do pedido #{pedido_atual.numero} --")
    print(f"Cliente: {pedido_atual.cliente.nome}")

    if pedido_atual.esta_vazio():
        print("O pedido está vazio.")
        return

    for item in pedido_atual.itens:
        print(f"  - {item}  |  frete: {servicos.formatar_moeda(item.calcular_frete())}")

    subtotal = pedido_atual.calcular_subtotal()
    frete = pedido_atual.calcular_frete_total()
    total = pedido_atual.calcular_total()

    print(f"Subtotal: {servicos.formatar_moeda(subtotal)}")
    print(f"Frete:    {servicos.formatar_moeda(frete)}")
    print(f"Total:    {servicos.formatar_moeda(total)}")


def finalizar_pedido():
    global pedido_atual

    if pedido_atual is None:
        print("Nenhum pedido em aberto.")
        return

    ver_resumo_pedido()

    if pedido_atual.esta_vazio():
        return

    total = pedido_atual.calcular_total()
    cliente = pedido_atual.cliente

    # operadores lógicos e de comparação combinados
    if cliente.saldo >= total and not pedido_atual.finalizado:
        if servicos.confirmar("Confirmar pagamento e finalizar pedido?"):
            sucesso = pedido_atual.finalizar()
            if sucesso:
                pedidos_finalizados.append(pedido_atual)
                print("Pedido finalizado com sucesso!")
                print(f"Saldo restante do cliente: {servicos.formatar_moeda(cliente.saldo)}")
                pedido_atual = None
            else:
                print("Não foi possível finalizar o pedido.")
    else:
        print("Saldo insuficiente para finalizar o pedido.")


def ver_historico():
    print("\n-- Histórico de pedidos finalizados --")
    if len(pedidos_finalizados) == 0:
        print("Nenhum pedido finalizado ainda.")
        return

    for pedido in pedidos_finalizados:
        print(f"  {pedido}  -  total pago: {servicos.formatar_moeda(pedido.calcular_total())}")


# ---------------------------------------------------------------------------
# Loop principal do programa
# ---------------------------------------------------------------------------

def main():
    print("Bem-vindo(a) ao sistema Loja & Estoque!")

    continuar = True
    while continuar:  # loop while
        exibir_menu_principal()
        opcao = input("Escolha uma opção: ").strip()

        if opcao == "1":
            cadastrar_produto_fisico()
        elif opcao == "2":
            cadastrar_produto_digital()
        elif opcao == "3":
            listar_produtos()
        elif opcao == "4":
            remover_produto()
        elif opcao == "5":
            buscar_produto()
        elif opcao == "6":
            cadastrar_cliente()
        elif opcao == "7":
            listar_clientes()
        elif opcao == "8":
            iniciar_pedido()
        elif opcao == "9":
            adicionar_item_pedido()
        elif opcao == "10":
            remover_item_pedido()
        elif opcao == "11":
            ver_resumo_pedido()
        elif opcao == "12":
            finalizar_pedido()
        elif opcao == "13":
            ver_historico()
        elif opcao == "0":
            continuar = False
            print("Encerrando o sistema. Até logo!")
        else:
            print("Opção inválida. Tente novamente.")


# Só executa main() se este arquivo for rodado diretamente
if __name__ == "__main__":
    main()
