# estoque.py
# Classe responsável por gerenciar os produtos disponíveis na loja.


class Estoque:
    """Guarda e gerencia a lista de produtos da loja."""

    def __init__(self):
        self._produtos = []  # lista de objetos Produto (encapsulada)

    def adicionar_produto(self, produto):
        self._produtos.append(produto)

    def remover_produto(self, indice):
        if 0 <= indice < len(self._produtos):
            return self._produtos.pop(indice)
        return None

    def buscar_por_nome(self, nome):
        """Procura um produto pelo nome (case-insensitive)."""
        for produto in self._produtos:
            if produto.nome.lower() == nome.lower():
                return produto
        return None

    def produto_existe(self, nome):
        # 'in' funciona aqui porque percorremos os nomes numa lista
        nomes_cadastrados = [p.nome.lower() for p in self._produtos]
        return nome.lower() in nomes_cadastrados   # operador in

    def listar(self):
        return self._produtos

    def total_itens(self):
        return len(self._produtos)

    def valor_total_estoque(self):
        total = 0.0
        for produto in self._produtos:
            total += produto.valor_total_em_estoque()
        return total

    def __len__(self):
        # Permite usar len(estoque) diretamente
        return len(self._produtos)
