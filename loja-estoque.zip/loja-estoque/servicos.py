# servicos.py
# Funções auxiliares/utilitárias que não pertencem diretamente a uma classe.


def ler_texto(mensagem):
    """Lê uma string do usuário, garantindo que não fique vazia."""
    texto = input(mensagem).strip()
    while texto == "":
        print("Este campo não pode ficar vazio.")
        texto = input(mensagem).strip()
    return texto


def ler_float(mensagem):
    """Lê um número decimal do usuário, tratando erros de conversão."""
    while True:
        entrada = input(mensagem)
        try:
            valor = float(entrada)      # conversão de tipo (str -> float)
            return abs(valor)           # abs() garante valor sempre positivo
        except ValueError:
            print(f'"{entrada}" não é um número válido. Tente novamente.')


def ler_int(mensagem):
    """Lê um número inteiro do usuário, tratando erros de conversão."""
    while True:
        entrada = input(mensagem)
        try:
            valor = int(entrada)        # conversão de tipo (str -> int)
            return abs(valor)
        except ValueError:
            print(f'"{entrada}" não é um número inteiro válido. Tente novamente.')


def confirmar(mensagem):
    """Pergunta sim/não ao usuário e retorna um booleano."""
    resposta = input(f"{mensagem} (s/n): ").strip().lower()
    # operador lógico "and" combinando duas condições
    return resposta == "s" or resposta == "sim"


def formatar_moeda(valor):
    return f"R$ {valor:.2f}"


def listar_com_numeros(itens):
    """
    Imprime uma lista de itens numerada, usando range() e f-strings.
    Ex.: 1 - Produto A
         2 - Produto B
    """
    if len(itens) == 0:
        print("(lista vazia)")
        return

    for i in range(len(itens)):   # uso explícito de range()
        print(f"{i + 1} - {itens[i]}")
